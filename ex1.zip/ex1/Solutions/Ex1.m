data = load('ex1data1.txt');

X = data(:,1);
y = data(:,2);

m = length(X);

%surf(X, y, Z); % Plot the data 
%ylabel('Profit in $10,000s'); % Set the y−axis label 
%xlabel('Population of City in 10,000s'); % Set the x−axis label

X = [ones(m,1),data(:,1)]; % Add a column of ones to x
theta = zeros(2, 1); % initialize fitting parameters
iterations = 1500;
alpha = 0.01;

plot(X,y,'rx')

x = 3:0.1:25;
Y = -3.6303 + 1.1664*x;
hold on
plot(x,Y)


